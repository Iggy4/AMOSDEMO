# Synapse V1.2

Single-file interactive CNC machine manager demo with loading board, maintenance modals, safety/procedure popups, 3D machine panel, and baseline/anomaly learning. Upload only `index.html` to GitHub Pages.
